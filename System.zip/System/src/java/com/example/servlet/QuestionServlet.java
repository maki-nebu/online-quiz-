package com.example;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class QuestionServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3305/quiz_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "mysql";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String questionId = request.getParameter("id");

        try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            if ("delete".equalsIgnoreCase(action) && questionId != null) {
                deleteQuestion(con, Integer.parseInt(questionId));
                response.getWriter().write("Question deleted successfully.");
            } else {
                response.getWriter().write("Invalid action or missing ID.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }
    }

    private void deleteQuestion(Connection con, int questionId) throws SQLException {
        String query = "DELETE FROM questions WHERE question_id = ?";
        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
        }
    }
}
