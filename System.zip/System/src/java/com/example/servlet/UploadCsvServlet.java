import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("/uploadCsv")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2, // 2MB
    maxFileSize = 1024 * 1024 * 10,      // 10MB
    maxRequestSize = 1024 * 1024 * 50   // 50MB
)
public class UploadCsvServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3305/System_exam";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "mysql";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Get the uploaded CSV file
            Part filePart = request.getPart("csvFile");
            if (filePart == null || filePart.getSize() == 0) {
                out.println("<h3>Error: No file uploaded.</h3>");
                return;
            }

            InputStream fileContent = filePart.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(fileContent));
            String line;
            boolean headerSkipped = false;

            // Database connection
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String checkCourseSql = "SELECT COUNT(*) FROM courses WHERE course_id = ?";
            PreparedStatement courseCheckStmt = conn.prepareStatement(checkCourseSql);

            // Adjusted insert statement without exam_code
            String insertQuestionSql = "INSERT INTO questions (question_id, course_id, question_text, question_type, option_1, option_2, option_3, option_4, correct_option, correct_answer) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuestionSql);

            int insertedCount = 0;

            while ((line = reader.readLine()) != null) {
                if (!headerSkipped) {
                    headerSkipped = true; // Skip the header row
                    continue;
                }

                String[] data = line.split(",", -1); // Use -1 to include empty trailing fields
                if (data.length != 10) { // Ensure the row has exactly 10 columns
                    out.println("<p>Skipping invalid row: " + line + "</p>");
                    continue;
                }

                int courseId;
                try {
                    courseId = Integer.parseInt(data[1].trim());
                } catch (NumberFormatException e) {
                    out.println("<p>Invalid course_id in row: " + line + "</p>");
                    continue;
                }

                // Check if the course exists
                courseCheckStmt.setInt(1, courseId);
                ResultSet rs = courseCheckStmt.executeQuery();
                rs.next();
                if (rs.getInt(1) == 0) {
                    out.println("<p>Course with course_id " + courseId + " does not exist. Skipping this question.</p>");
                    continue;
                }

                try {
                    // Insert the question into the database
                    insertStmt.setInt(1, Integer.parseInt(data[0].trim())); // question_id
                    insertStmt.setInt(2, courseId); // course_id
                    insertStmt.setString(3, data[2].trim()); // question_text
                    insertStmt.setString(4, data[3].trim()); // question_type
                    insertStmt.setString(5, data[4].trim()); // option_1
                    insertStmt.setString(6, data[5].trim()); // option_2
                    insertStmt.setString(7, data[6].trim()); // option_3
                    insertStmt.setString(8, data[7].trim()); // option_4
                    insertStmt.setInt(9, Integer.parseInt(data[8].trim())); // correct_option
                    insertStmt.setString(10, data[9].trim()); // correct_answer
                    insertStmt.addBatch();
                    insertedCount++;
                } catch (Exception e) {
                    out.println("<p>Error inserting row: " + line + " - " + e.getMessage() + "</p>");
                }
            }

            int[] results = insertStmt.executeBatch();
            conn.close();

            out.println("<h3>Upload successful! " + insertedCount + " rows inserted into the database.</h3>");
        } catch (Exception e) {
            e.printStackTrace(out);
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}
