
public class QuizResult {
    private String questionText;
    private String answerText;
    private String answerOption;
    private String correctAnswer;
    private String questionType; // "choice" or "short"

    // Constructor
    public QuizResult(String questionText, String answerText, String answerOption, String correctAnswer, String questionType) {
        this.questionText = questionText;
        this.answerText = answerText;
        this.answerOption = answerOption;
        this.correctAnswer = correctAnswer;
        this.questionType = questionType;
    }

    // Getters
    public String getQuestionText() {
        return questionText;
    }

    public String getAnswerText() {
        return answerText;
    }

    public String getAnswerOption() {
        return answerOption;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public String getQuestionType() {
        return questionType;
    }
}